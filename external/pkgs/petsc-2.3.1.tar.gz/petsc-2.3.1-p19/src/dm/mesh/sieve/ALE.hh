#ifndef included_ALE_ALE_hh
#define included_ALE_ALE_hh

#include <petsc.h>

#ifndef  included_ALE_exception_hh
#include <ALE_exception.hh>
#endif
#ifndef  included_ALE_mem_hh
#include <ALE_mem.hh>
#endif
#ifndef  included_ALE_containers_hh
#include <ALE_containers.hh>
#endif
#ifndef  included_ALE_log_hh
#include <ALE_log.hh>
#endif


#endif
